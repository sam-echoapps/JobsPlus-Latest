require(["require", "exports", "knockout", "ojs/ojbootstrap", "ojs/ojarraydataprovider", "ojs/ojknockout", "ojs/ojchart", "jet-composites/demo-chart-three-d-effect-control/loader"], function (require, exports, ko, ojbootstrap_1, data, ArrayDataProvider) {
    "use strict";
    
    class ChartModel {
        constructor() {
            this.threeDValue = ko.observable("off");

            var data = [
                {
                    "id": 0,
                    "series": "Series 1",
                    "group": "Group A",
                    "value": 42
                },
                {
                    "id": 1,
                    "series": "Series 2",
                    "group": "Group A",
                    "value": 55
                },
                {
                    "id": 2,
                    "series": "Series 3",
                    "group": "Group A",
                    "value": 36
                },
                {
                    "id": 3,
                    "series": "Series 4",
                    "group": "Group A",
                    "value": 22
                },
                {
                    "id": 4,
                    "series": "Series 5",
                    "group": "Group A",
                    "value": 22
                }
            ];
            
            // Now 'data' variable contains your JSON array
            console.log(data);
            
            /* chart data */
            this.dataProvider = new ArrayDataProvider(JSON.parse(data), {
                keyAttributes: "id",
            });
        }
    }
    (0, ojbootstrap_1.whenDocumentReady)().then(() => {
        ko.applyBindings(new ChartModel(), document.getElementById("chart-container"));
    });
});